﻿namespace ArtPlantMall.Styles
{
    public partial class Fonts 
	{
		public Fonts ()
		{
			InitializeComponent ();
		}
	}
}