﻿namespace ArtPlantMall.Styles
{
    public partial class Colors 
	{
		public Colors ()
		{
			InitializeComponent ();
		}
	}
}