﻿using Xamarin.Forms;

namespace ArtPlantMall.Views.Templates
{
    public partial class ExpandedBasketItemTemplate : ContentView
	{
		public ExpandedBasketItemTemplate ()
		{
			InitializeComponent ();
		}
	}
}