﻿using Xamarin.Forms;

namespace ArtPlantMall.Views.Templates
{
    public partial class CollapsedBasketItemTemplate : ContentView
	{
		public CollapsedBasketItemTemplate()
		{
			InitializeComponent ();
		}
	}
}