﻿using Xamarin.Forms;

namespace ArtPlantMall.Views.Templates
{
    public partial class BasketDeliveryItemTemplate : ContentView
	{
		public BasketDeliveryItemTemplate ()
		{
			InitializeComponent ();
		}
	}
}