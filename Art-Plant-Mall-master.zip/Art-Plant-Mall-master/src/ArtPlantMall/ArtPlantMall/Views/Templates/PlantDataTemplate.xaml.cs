﻿using Xamarin.Forms;

namespace ArtPlantMall.Views.Templates
{
    public partial class PlantDataTemplate : ContentView
    {
        public PlantDataTemplate()
        {
            InitializeComponent();
        }
    }
}